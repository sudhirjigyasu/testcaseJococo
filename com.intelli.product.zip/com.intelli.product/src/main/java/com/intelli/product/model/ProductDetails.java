package com.intelli.product.model;

public class ProductDetails extends ProductCost {

	
}
