package com.intelli.product.service;

import org.springframework.stereotype.Service;

import com.intelli.product.constant.ProductConstant;
import com.intelli.product.model.ProductCost;
import com.intelli.product.model.ProductDetails;

@Service
public class PriceCalculateService {

	public ProductCost calculateProductTax(ProductDetails productDetails) {
		ProductCost cost = new ProductCost();
		double tax, totalprice;
		if (productDetails.getProductType().equalsIgnoreCase(ProductConstant.CATEGORY_A)) {

			tax = productDetails.getPrice() * 0.1;
			totalprice = productDetails.getPrice() + tax;
			cost.setTax(tax);
			cost.setPrice(totalprice);
			cost.setDesc(productDetails.getDesc());
			cost.setName(productDetails.getName());
			cost.setProductType(productDetails.getProductType());
		} else if (productDetails.getProductType().equalsIgnoreCase(ProductConstant.CATEGORY_B)) {

			tax = productDetails.getPrice() * 0.2;
			totalprice = productDetails.getPrice() + tax;
			cost.setTax(tax);
			cost.setPrice(totalprice);
			cost.setDesc(productDetails.getDesc());
			cost.setName(productDetails.getName());
			cost.setProductType(productDetails.getProductType());
			
		} else { /*if (productDetails.getProductType().equalsIgnoreCase(ProductConstant.CATEGORY_C)) {*/
			cost.setTax(0.0);
			cost.setPrice(productDetails.getPrice());
			cost.setDesc(productDetails.getDesc());
			cost.setName(productDetails.getName());
			cost.setProductType(productDetails.getProductType());
		}
		return cost;
	}
}
