package com.intelli.product.model;

public class ProductCost {

	private Double price;
	private Double tax;
	private String name;
	private String desc;
	private String productType;

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Double getTax() {
		return tax;
	}

	public void setTax(Double tax) {
		this.tax = tax;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	@Override
	public String toString() {
		return "ProductCost [price=" + price + ", tax=" + tax + ", name=" + name + ", desc=" + desc + ", productType="
				+ productType + "]";
	}

}
